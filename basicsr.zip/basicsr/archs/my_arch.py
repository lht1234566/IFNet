import torch.nn as nn
import torch
import torch.nn.functional as F
from einops import rearrange
from torch import einsum
import math
import warnings
from basicsr.utils.ops_util import linear, conv_nd, avg_pool_nd, zero_module, normalization, timestep_embedding
from torch.nn.init import _calculate_fan_in_and_fan_out
from collections import defaultdict, Counter
import numpy as np
from tqdm import tqdm
import random
from abc import abstractmethod
# from swin_unet_arch import ResBlock

def uniform(a, b, shape, device='cuda'):
    return (b - a) * torch.rand(shape, device=device) + a


class AsymmetricTransform:

    def Q(self, *args, **kwargs):
        raise NotImplementedError('Query transform not implemented')

    def K(self, *args, **kwargs):
        raise NotImplementedError('Key transform not implemented')


class LSH:
    def __call__(self, *args, **kwargs):
        raise NotImplementedError('LSH scheme not implemented')

    def compute_hash_agreement(self, q_hash, k_hash):
        return (q_hash == k_hash).min(dim=-1)[0].sum(dim=-1)


class XBOXPLUS(AsymmetricTransform):

    def set_norms(self, x):
        self.x_norms = x.norm(p=2, dim=-1, keepdim=True)
        self.MX = torch.amax(self.x_norms, dim=-2, keepdim=True)

    def X(self, x):
        device = x.device
        ext = torch.sqrt((self.MX ** 2).to(device) - (self.x_norms ** 2).to(device))
        zero = torch.tensor(0.0, device=x.device).repeat(x.shape[:-1], 1).unsqueeze(-1)
        return torch.cat((x, ext, zero), -1)


def lsh_clustering(x, n_rounds, r=1):
    salsh = SALSH(n_rounds=n_rounds, dim=x.shape[-1], r=r, device=x.device)
    x_hashed = salsh(x).reshape((n_rounds,) + x.shape[:-1])
    return x_hashed.argsort(dim=-1)


class SALSH(LSH):
    def __init__(self, n_rounds, dim, r, device='cuda'):
        super(SALSH, self).__init__()
        self.alpha = torch.normal(0, 1, (dim, n_rounds), device=device)
        self.beta = uniform(0, r, shape=(1, n_rounds), device=device)
        self.dim = dim
        self.r = r

    def __call__(self, vecs):
        projection = vecs @ self.alpha
        projection_shift = projection + self.beta
        projection_rescale = projection_shift / self.r
        return projection_rescale.permute(2, 0, 1)


def _no_grad_trunc_normal_(tensor, mean, std, a, b):
    def norm_cdf(x):
        return (1. + math.erf(x / math.sqrt(2.))) / 2.

    if (mean < a - 2 * std) or (mean > b + 2 * std):
        warnings.warn("mean is more than 2 std from [a, b] in nn.init.trunc_normal_. "
                      "The distribution of values may be incorrect.",
                      stacklevel=2)

    with torch.no_grad():
        l = norm_cdf((a - mean) / std)
        u = norm_cdf((b - mean) / std)
        tensor.uniform_(2 * l - 1, 2 * u - 1)
        tensor.erfinv_()
        tensor.mul_(std * math.sqrt(2.))
        tensor.add_(mean)
        tensor.clamp_(min=a, max=b)
        return tensor


def trunc_normal_(tensor, mean=0., std=1., a=-2., b=2.):
    return _no_grad_trunc_normal_(tensor, mean, std, a, b)


def variance_scaling_(tensor, scale=1.0, mode='fan_in', distribution='normal'):
    fan_in, fan_out = _calculate_fan_in_and_fan_out(tensor)
    if mode == 'fan_in':
        denom = fan_in
    elif mode == 'fan_out':
        denom = fan_out
    elif mode == 'fan_avg':
        denom = (fan_in + fan_out) / 2

    variance = scale / denom

    if distribution == "truncated_normal":
        trunc_normal_(tensor, std=math.sqrt(variance) / .87962566103423978)
    elif distribution == "normal":
        tensor.normal_(std=math.sqrt(variance))
    elif distribution == "uniform":
        bound = math.sqrt(3 * variance)
        tensor.uniform_(-bound, bound)
    else:
        raise ValueError(f"invalid distribution {distribution}")


def lecun_normal_(tensor):
    variance_scaling_(tensor, mode='fan_in', distribution='truncated_normal')


class PreNorm(nn.Module):
    def __init__(self, dim, fn):
        super().__init__()
        self.fn = fn
        self.norm = nn.LayerNorm(dim)

    def forward(self, x, *args, **kwargs):
        x = self.norm(x)
        return self.fn(x, *args, **kwargs)


class GELU(nn.Module):
    def forward(self, x):
        return F.gelu(x)


def batch_scatter(output, src, dim, index):
    """
    :param output: [b,n,c]
    :param src: [b,n,c]
    :param dim: int
    :param index: [b,n]
    :return: output: [b,n,c]
    """
    b, k, c = src.shape
    index = index[:, :, None].expand(-1, -1, c)
    output, src, index = map(lambda t: rearrange(t, 'b k c -> (b c) k'), (output, src, index))
    output.scatter_(dim, index, src)
    output = rearrange(output, '(b c) k -> b k c', b=b)
    return output


def batch_gather(x, index, dim):
    """
    :param x: [b,n,c]
    :param index: [b,n//2]
    :param dim: int
    :return: output: [b,n//2,c]
    """
    b, n, c = x.shape
    index = index[:, :, None].expand(-1, -1, c)
    x, index = map(lambda t: rearrange(t, 'b n c -> (b c) n'), (x, index))
    output = torch.gather(x, dim, index)
    output = rearrange(output, '(b c) n -> b n c', b=b)
    return output


class FeedForward(nn.Module):
    def __init__(self, dim, mult=4):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv2d(dim, dim * mult, 1, 1, bias=False),
            GELU(),
            nn.Conv2d(dim * mult, dim * mult, 3, 1, 1, bias=False, groups=dim * mult),
            GELU(),
            nn.Conv2d(dim * mult, dim, 1, 1, bias=False),
        )

    def forward(self, x):
        """
        x: [b,h,w,c]
        return out: [b,h,w,c]
        """
        out = self.net(x.permute(0, 3, 1, 2))
        return out.permute(0, 2, 3, 1)

class SAH_MSA(nn.Module):
    def __init__(self, heads=4, n_rounds=2, channels=64, patch_size=144,
                 r=1):
        super(SAH_MSA, self).__init__()
        self.heads = heads
        self.n_rounds = n_rounds
        inner_dim = channels * 3
        self.to_q = nn.Linear(channels, inner_dim, bias=False)
        self.to_k = nn.Linear(channels, inner_dim, bias=False)
        self.to_v = nn.Linear(channels, inner_dim, bias=False)
        self.to_out = nn.Linear(inner_dim, channels, bias=False)

        self.xbox_plus = XBOXPLUS()
        self.clustering_params = {
            'r': r,
            'n_rounds': self.n_rounds
        }
        self.q_attn_size = patch_size[0] * patch_size[1]
        self.k_attn_size = patch_size[0] * patch_size[1]

    def forward(self, input):
        """
        :param input: [b,n,c]
        :return: output: [b,n,c]
        """

        B, N, C_inp = input.shape
        query = self.to_q(input)
        key = self.to_k(input)
        value = self.to_v(input)
        input_hash = input.view(B, N, self.heads, C_inp // self.heads)
        x_hash = rearrange(input_hash, 'b t h e -> (b h) t e')
        bs, x_seqlen, dim = x_hash.shape
        with torch.no_grad():
            self.xbox_plus.set_norms(x_hash)
            Xs = self.xbox_plus.X(x_hash)
            x_positions = lsh_clustering(Xs, **self.clustering_params)
            x_positions = x_positions.reshape(self.n_rounds, bs, -1)

        del Xs

        C = query.shape[-1]
        query = query.view(B, N, self.heads, C // self.heads)
        key = key.view(B, N, self.heads, C // self.heads)
        value = value.view(B, N, self.heads, C // self.heads)

        query = rearrange(query, 'b t h e -> (b h) t e')  # [bs, q_seqlen,c]
        key = rearrange(key, 'b t h e -> (b h) t e')
        value = rearrange(value, 'b s h d -> (b h) s d')

        bs, q_seqlen, dim = query.shape
        bs, k_seqlen, dim = key.shape
        v_dim = value.shape[-1]

        x_rev_positions = torch.argsort(x_positions, dim=-1)
        x_offset = torch.arange(bs, device=query.device).unsqueeze(-1) * x_seqlen
        x_flat = (x_positions + x_offset).reshape(-1)

        s_queries = query.reshape(-1, dim).index_select(0, x_flat).reshape(-1, self.q_attn_size, dim)
        s_keys = key.reshape(-1, dim).index_select(0, x_flat).reshape(-1, self.k_attn_size, dim)
        s_values = value.reshape(-1, v_dim).index_select(0, x_flat).reshape(-1, self.k_attn_size, v_dim)

        inner = s_queries @ s_keys.transpose(2, 1)
        norm_factor = 1
        inner = inner / norm_factor

        # free memory
        del x_positions

        # softmax denominator
        dots_logsumexp = torch.logsumexp(inner, dim=-1, keepdim=True)
        # softmax
        dots = torch.exp(inner - dots_logsumexp)
        # dropout

        # n_rounds outs
        bo = (dots @ s_values).reshape(self.n_rounds, bs, q_seqlen, -1)

        # undo sort
        x_offset = torch.arange(bs * self.n_rounds, device=query.device).unsqueeze(-1) * x_seqlen
        x_rev_flat = (x_rev_positions.reshape(-1, x_seqlen) + x_offset).reshape(-1)
        o = bo.reshape(-1, v_dim).index_select(0, x_rev_flat).reshape(self.n_rounds, bs, q_seqlen, -1)

        slogits = dots_logsumexp.reshape(self.n_rounds, bs, -1)
        logits = torch.gather(slogits, 2, x_rev_positions)

        # free memory
        del x_rev_positions

        # weighted sum multi-round attention
        probs = torch.exp(logits - torch.logsumexp(logits, dim=0, keepdim=True))
        out = torch.sum(o * probs.unsqueeze(-1), dim=0)
        out = rearrange(out, '(b h) t d -> b t h d', h=self.heads)
        out = out.reshape(B, N, -1)
        out = self.to_out(out)

        return out


class SAHAB(nn.Module):
    def __init__(
            self,
            dim,
            patch_size=(8, 8),
            heads=8,
            shift_size=0,
            sparse=False
    ):
        super().__init__()
        self.blocks = nn.ModuleList([])
        self.attn = PreNorm(dim, SAH_MSA(heads=heads, n_rounds=2, r=1, channels=dim, patch_size=patch_size))
        self.ffn = PreNorm(dim, FeedForward(dim=dim))
        self.shift_size = shift_size
        self.patch_size = patch_size
        self.sparse = sparse

    def forward(self, x, mask=None):
        """
        x: [b,h,w,c]
        mask: [b,h,w]
        return out: [b,h,w,c]
        """
        b, h, w, c = x.shape
        if self.shift_size > 0:
            x = torch.roll(x, shifts=(-self.shift_size, -self.shift_size), dims=(1, 2))
            mask = torch.roll(mask, shifts=(-self.shift_size, -self.shift_size), dims=(1, 2))
        w_size = self.patch_size

        # Split into large patches
        x = rearrange(x, 'b (nh hh) (nw ww) c-> b (nh nw) (hh ww c)', hh=w_size[0] * 2, ww=w_size[1] * 2)
        mask = rearrange(mask, 'b (nh hh) (nw ww) -> b (nh nw) (hh ww)', hh=w_size[0] * 2, ww=w_size[1] * 2)
        N = x.shape[1]

        mask = torch.mean(mask, dim=2, keepdim=False)  # [b,nh*nw]
        if self.sparse:
            mask_select = mask.topk(mask.shape[1] // 2, dim=1)[1]  # [b,nh*nw//2]
            x_select = batch_gather(x, mask_select, 1)  # [b,nh*nw//2,hh*ww*c]
            x_select = x_select.reshape(b * N // 2, -1, c)
            x_select = self.attn(x_select) + x_select
            x_select = x_select.view(b, N // 2, -1)
            x = batch_scatter(x.clone(), x_select, 1, mask_select)
        else:
            x = x.view(b * N, -1, c)
            x = self.attn(x) + x
            x = x.view(b, N, -1)
        x = rearrange(x, 'b (nh nw) (hh ww c) -> b (nh hh) (nw ww) c', nh=h // (w_size[0] * 2), hh=w_size[0] * 2,
                      ww=w_size[1] * 2)

        if self.shift_size > 0:
            x = torch.roll(x, shifts=(self.shift_size, self.shift_size), dims=(1, 2))

        x = self.ffn(x) + x

        return x


class SAHABs(nn.Module):
    def __init__(
            self,
            dim,
            patch_size=(8, 8),
            heads=8,
            num_blocks=2,
            sparse=False
    ):
        super().__init__()
        blocks = []
        for _ in range(num_blocks):
            blocks.append(
                SAHAB(heads=heads, dim=dim, patch_size=patch_size, sparse=sparse,
                      shift_size=0 if (_ % 2 == 0) else patch_size[0]))
        self.blocks = nn.Sequential(*blocks)

    def forward(self, x, mask=None):
        """
        x: [b,c,h,w]
        mask: [b,1,h,w]
        return x: [b,c,h,w]
        """
        x = x.permute(0, 2, 3, 1)
        mask = mask.squeeze(1)
        for block in self.blocks:
            x = block(x, mask)
        x = x.permute(0, 3, 1, 2)
        return x


class ASPPConv(nn.Sequential):
    def __init__(self, in_channels, out_channels, dilation):
        modules = [
            nn.Conv2d(in_channels, out_channels, 3, padding=dilation, dilation=dilation, bias=False),
            nn.ReLU()
        ]
        super(ASPPConv, self).__init__(*modules)


class ASPPPooling(nn.Sequential):
    def __init__(self, in_channels, out_channels):
        super(ASPPPooling, self).__init__(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(in_channels, out_channels, 1, bias=False),
            nn.ReLU())

    def forward(self, x):
        size = x.shape[-2:]
        for mod in self:
            x = mod(x)
        return F.interpolate(x, size=size, mode='bilinear', align_corners=False)


class ASPP(nn.Module):
    def __init__(self, in_channels, atrous_rates, out_channels):
        super(ASPP, self).__init__()
        modules = []

        rates = tuple(atrous_rates)
        for rate in rates:
            modules.append(ASPPConv(in_channels, out_channels, rate))

        modules.append(ASPPPooling(in_channels, out_channels))

        self.convs = nn.ModuleList(modules)

        self.project = nn.Sequential(
            nn.Conv2d(len(self.convs) * out_channels, out_channels, 1, bias=False),
            nn.ReLU(),
            nn.Dropout(0.5))

    def forward(self, x):
        res = []
        for conv in self.convs:
            res.append(conv(x))
        res = torch.cat(res, dim=1)
        return self.project(res)
class TimestepBlock(nn.Module):
    """
    Any module where forward() takes timestep embeddings as a second argument.
    """

    @abstractmethod
    def forward(self, x, emb):
        """
        Apply the module to `x` given `emb` timestep embeddings.
        """
class TimestepEmbedSequential(nn.Sequential, TimestepBlock):
    """
    A sequential module that passes timestep embeddings to the children that
    support it as an extra input.
    """

    def forward(self, x, emb):
        for layer in self:
            if isinstance(layer, TimestepBlock):
                x = layer(x, emb)
                print('zheli ')
            else:
                x = layer(x)
        return x
class Upsample(nn.Module):
    """
    An upsampling layer with an optional convolution.
    :param channels: channels in the inputs and outputs.
    :param use_conv: a bool determining if a convolution is applied.
    :param dims: determines if the signal is 1D, 2D, or 3D. If 3D, then
                 upsampling occurs in the inner-two dimensions.
    """

    def __init__(self, channels, use_conv, dims=2, out_channels=None):
        super().__init__()
        self.channels = channels
        self.out_channels = out_channels or channels
        self.use_conv = use_conv
        self.dims = dims
        if use_conv:
            self.conv = conv_nd(dims, self.channels, self.out_channels, 3, padding=1)

    def forward(self, x):
        assert x.shape[1] == self.channels
        if self.dims == 3:
            x = F.interpolate(
                x, (x.shape[2], x.shape[3] * 2, x.shape[4] * 2), mode="nearest"
            )
        else:
            x = F.interpolate(x, scale_factor=2, mode="nearest")
        if self.use_conv:
            x = self.conv(x)
        return x
class Downsample(nn.Module):
    """
    A downsampling layer with an optional convolution.
    :param channels: channels in the inputs and outputs.
    :param use_conv: a bool determining if a convolution is applied.
    :param dims: determines if the signal is 1D, 2D, or 3D. If 3D, then
                 downsampling occurs in the inner-two dimensions.
    """
    def __init__(self, channels, use_conv, dims=2, out_channels=None):
        super().__init__()
        self.channels = channels
        self.out_channels = out_channels or channels
        self.use_conv = use_conv
        self.dims = dims
        stride = 2 if dims != 3 else (1, 2, 2)
        if use_conv:
            self.op = conv_nd(
                dims, self.channels, self.out_channels, 3, stride=stride, padding=1
            )
        else:
            assert self.channels == self.out_channels
            self.op = avg_pool_nd(dims, kernel_size=stride, stride=stride)

    def forward(self, x):
        assert x.shape[1] == self.channels
        return self.op(x)
class TimestepEmbedder(nn.Module):
    """
    Embeds scalar timesteps into vector representations.
    """

    def __init__(self, hidden_size, frequency_embedding_size=256):
        super().__init__()
        self.mlp = nn.Sequential(
            nn.Linear(frequency_embedding_size, hidden_size, bias=True),
            nn.SiLU(),
            nn.Linear(hidden_size, hidden_size, bias=True),
        )
        self.frequency_embedding_size = frequency_embedding_size

    @staticmethod
    def timestep_embedding(t, dim, max_period=10000):
        """
        Create sinusoidal timestep embeddings.
        :param t: a 1-D Tensor of N indices, one per batch element.
                          These may be fractional.
        :param dim: the dimension of the output.
        :param max_period: controls the minimum frequency of the embeddings.
        :return: an (N, D) Tensor of positional embeddings.
        """
        # https://github.com/openai/glide-text2im/blob/main/glide_text2im/nn.py
        half = dim // 2
        freqs = torch.exp(
            -math.log(max_period) * torch.arange(start=0, end=half, dtype=torch.float32) / half
        ).to(device=t.device)
        args = t[:, None].float() * freqs[None]
        embedding = torch.cat([torch.cos(args), torch.sin(args)], dim=-1)
        if dim % 2:
            embedding = torch.cat([embedding, torch.zeros_like(embedding[:, :1])], dim=-1)
        return embedding

    def forward(self, t):
        t_freq = self.timestep_embedding(t, self.frequency_embedding_size)
        t_emb = self.mlp(t_freq)
        return t_emb
class ResBlock(TimestepBlock):
    """
    A residual block that can optionally change the number of channels.
    :param channels: the number of input channels.
    :param emb_channels: the number of timestep embedding channels.
    :param dropout: the rate of dropout.
    :param out_channels: if specified, the number of out channels.
    :param use_conv: if True and out_channels is specified, use a spatial
        convolution instead of a smaller 1x1 convolution to change the
        channels in the skip connection.
    :param dims: determines if the signal is 1D, 2D, or 3D.
    :param up: if True, use this block for upsampling.
    :param down: if True, use this block for downsampling.
    """
    def __init__(
        self,
        channels,
        emb_channels,
        dropout,
        out_channels=None,
        use_conv=False,
        use_scale_shift_norm=False,
        dims=2,
        up=False,
        down=False,
    ):
        super().__init__()
        self.channels = channels
        self.emb_channels = emb_channels
        self.dropout = dropout
        self.out_channels = out_channels or channels
        self.use_conv = use_conv
        self.use_scale_shift_norm = use_scale_shift_norm
        # print(channels)
        self.in_layers = nn.Sequential(
            normalization(channels),
            nn.SiLU(),
            conv_nd(dims, channels, self.out_channels, 3, padding=1),
        )

        self.updown = up or down

        if up:
            self.h_upd = Upsample(channels, False, dims)
            self.x_upd = Upsample(channels, False, dims)
        elif down:
            self.h_upd = Downsample(channels, False, dims)
            self.x_upd = Downsample(channels, False, dims)
        else:
            self.h_upd = self.x_upd = nn.Identity()

        self.emb_layers = nn.Sequential(
            nn.SiLU(),
            linear(
                emb_channels,
                2 * self.out_channels if use_scale_shift_norm else self.out_channels,
            ),
        )
        self.out_layers = nn.Sequential(
            normalization(self.out_channels),
            nn.SiLU(),
            nn.Dropout(p=dropout),
            zero_module(
                conv_nd(dims, self.out_channels, self.out_channels, 3, padding=1)
            ),
        )

        if self.out_channels == channels:
            self.skip_connection = nn.Identity()
        elif use_conv:
            self.skip_connection = conv_nd(
                dims, channels, self.out_channels, 3, padding=1
            )
        else:
            self.skip_connection = conv_nd(dims, channels, self.out_channels, 1)

    def forward(self, x, emb):
        # print(x.shape, emb.shape)
        if self.updown:
            in_rest, in_conv = self.in_layers[:-1], self.in_layers[-1]
            h = in_rest(x)
            h = self.h_upd(h)
            x = self.x_upd(x)
            h = in_conv(h)
        else:
            h = self.in_layers(x)
        emb_out = self.emb_layers(emb).type(h.dtype)
        while len(emb_out.shape) < len(h.shape):
            emb_out = emb_out[..., None]
        if self.use_scale_shift_norm:
            out_norm, out_rest = self.out_layers[0], self.out_layers[1:]
            scale, shift = torch.chunk(emb_out, 2, dim=1)
            h = out_norm(h) * (1 + scale) + shift
            h = out_rest(h)
        else:
            h = h + emb_out
            h = self.out_layers(h)
        return self.skip_connection(x) + h
class my_net(nn.Module):
    def __init__(self,image_size=64,
                 model_channels=160,
                 out_channels=3,
                 dim=48,
                 stage=2,
                 num_blocks=[2, 2, 2],
                 sparse=True,
                 use_fp16=False,
                 cond_lq=True,
                 lq_size=64,
                 channel_mult= [1, 2, 2, 4],
                 dims=2,
                 dropout=0,
                 use_scale_shift_norm=True
                 ):
        super(my_net, self).__init__()
        self.dim = dim
        self.stage = stage
        self.sparse = sparse
        self.model_channels = model_channels
        # Fution physical mask and shifted measurement

        self.dtype = torch.float16 if use_fp16 else torch.float32
        self.cond_lq = cond_lq
        time_embed_dim = model_channels * 4
        # Encoder
        self.encoder_layers = nn.ModuleList([])
        self.time_embed = nn.Sequential(
            linear(model_channels, time_embed_dim),
            nn.SiLU(),
            linear(time_embed_dim, time_embed_dim),
        )
        if cond_lq and lq_size == image_size:
            self.feature_extractor = nn.Identity()
            base_chn = 96
        else:
            feature_extractor = []
            feature_chn = 3
            base_chn = 16
            for ii in range(int(math.log(lq_size / image_size) / math.log(2))):
                feature_extractor.append(nn.Conv2d(feature_chn, base_chn, 3, 1, 1))
                feature_extractor.append(nn.SiLU())
                feature_extractor.append(Downsample(base_chn, True, out_channels=base_chn*2))
                base_chn *= 2
                feature_chn = base_chn
            self.feature_extractor = nn.Sequential(*feature_extractor)

        self.conv_before_upsample = nn.Sequential(
                nn.Conv2d(dim, dim, 3, 1, 1), nn.LeakyReLU(inplace=True))
        self.conv_up1 = nn.Conv2d(dim, dim, 3, 1, 1)
        self.conv_up2 = nn.Conv2d(dim, out_channels, 3, 1, 1)

        self.conv_before_upsample_mask = nn.Sequential(
                nn.Conv2d(1, 1, 3, 1, 1), nn.LeakyReLU(inplace=True))
        self.conv_up1_mask = nn.Conv2d(1, 1, 3, 1, 1)
        self.conv_up2_mask = nn.Conv2d(1, 1, 3, 1, 1)
        self.lrelu = nn.LeakyReLU(negative_slope=0.2, inplace=True)


        dim_stage = dim
        for i in range(stage):
            self.encoder_layers.append(nn.ModuleList([
                ResBlock(dim_stage,time_embed_dim,dropout,out_channels=dim_stage,
                         dims=dims,use_scale_shift_norm=use_scale_shift_norm),
                SAHABs(dim=dim_stage, num_blocks=num_blocks[i], heads=dim_stage // dim, sparse=sparse),
                nn.Conv2d(dim_stage, dim_stage * 2, 4, 2, 1, bias=False),
                nn.AvgPool2d(kernel_size=2, stride=2),
                ResBlock(dim_stage * 2, time_embed_dim, dropout, out_channels=dim_stage * 2,
                         dims=dims, use_scale_shift_norm=use_scale_shift_norm),
            ]))
            dim_stage *= 2
        # print(dim_stage)


        # Bottleneck
        self.bottleneck=nn.ModuleList([])
        for i in range(1):
            self.bottleneck.append(nn.ModuleList([
            ResBlock(dim_stage,time_embed_dim,dropout,out_channels=dim_stage,
                         dims=dims,use_scale_shift_norm=use_scale_shift_norm),
            SAHABs(dim=dim_stage, heads=dim_stage // dim, num_blocks=num_blocks[-1], sparse=sparse),
            ResBlock(dim_stage,time_embed_dim,dropout,out_channels=dim_stage ,
                         dims=dims,use_scale_shift_norm=use_scale_shift_norm) ]))

        # print(dim_stage)
        # Decoder
        self.decoder_layers = nn.ModuleList([])
        for i in range(stage):
            self.decoder_layers.append(nn.ModuleList([
                ResBlock(dim_stage, time_embed_dim, dropout, out_channels=dim_stage,
                         dims=dims, use_scale_shift_norm=use_scale_shift_norm),
                nn.ConvTranspose2d(dim_stage, dim_stage // 2, stride=2, kernel_size=2, padding=0, output_padding=0),
                SAHABs(dim=dim_stage // 2, num_blocks=num_blocks[stage - 1 - i],
                       heads=(dim_stage // 2) // dim, sparse=sparse),
                ResBlock(dim_stage // 2, time_embed_dim, dropout, out_channels=dim_stage // 2,
                         dims=dims, use_scale_shift_norm=use_scale_shift_norm),
            ]))
            dim_stage //= 2



        # Output projection
        self.out_proj = nn.Conv2d(dim_stage, dim_stage, 3, 1, 1, bias=False)

        #### activation function
        self.lrelu = nn.LeakyReLU(negative_slope=0.1, inplace=True)
        self.apply(self._init_weights)

    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            trunc_normal_(m.weight, std=.02)
            if isinstance(m, nn.Linear) and m.bias is not None:
                nn.init.constant_(m.bias, 0)
        elif isinstance(m, nn.LayerNorm):
            nn.init.constant_(m.bias, 0)
            nn.init.constant_(m.weight, 1.0)

    def forward(self, x,timesteps, un=None, lq=None):
        """
        x: [b,c,h,w] 原始特征
        mask[b,3,h,w] 经过稀疏性提取器提取的特征
         :param timesteps: a 1-D batch of timesteps.
        :param un: an [N x C x ...] Tensor of uncertainty estimation (not used).
        :param lq: an [N x C x ...] Tensor of low quality iamge.
        :return: an [N x C x ...] Tensor of outputs.
        return out:[b,c,h,w]
        """

        b, c, h, w = x.shape

        emb = self.time_embed(timestep_embedding(timesteps, self.model_channels)).type(self.dtype)

        fea, mask = x,x[:, -1]
        mask=mask.unsqueeze(1)

#         print(fea.shape, mask.shape)torch.Size([1, 144, 64, 64]) torch.Size([1, 1, 64, 64])
        fea = self.conv_before_upsample(fea)

        fea = self.lrelu(self.conv_up1(F.interpolate(fea, scale_factor=2, mode='nearest')))
        fea_or=fea

        mask = self.conv_before_upsample_mask(mask)
        mask = self.lrelu(self.conv_up1_mask(F.interpolate(mask, scale_factor=2, mode='nearest')))
        # mask = self.lrelu(self.conv_up2(F.interpolate(mask, scale_factor=2, mode='nearest')))


        # Encoder
        fea_encoder = []
        masks = []
        for (R1,Blcok, FeaDownSample, MaskDownSample,R2) in self.encoder_layers:
            # print(fea.shape)
            fea=R1(fea,emb)
            # print(fea.shape)
            fea = Blcok(fea, mask)
            masks.append(mask)
            fea_encoder.append(fea)
            fea = FeaDownSample(fea)
            mask = MaskDownSample(mask)
            fea = R2(fea, emb)
        # print(fea.shape)
        # Bottleneck
        for (R1, Blcok, R2) in self.bottleneck:
            fea = R1(fea, emb)
            fea = Blcok(fea, mask)
            fea = R2(fea, emb)

        # Decoder
        for i, (R1,FeaUpSample, Blcok,R2) in enumerate(self.decoder_layers):
            fea = R1(fea, emb)
            fea = FeaUpSample(fea)
            fea = fea + fea_encoder[self.stage - 1 - i]
            mask = masks[self.stage - 1 - i]
            fea = Blcok(fea, mask)
            fea = R2(fea, emb)
        # print(fea.shape)
        # Output projection
        fea = self.out_proj(fea) + fea_or
        fea = self.conv_before_upsample(fea)
        out = self.lrelu(self.conv_up2(F.interpolate(fea, scale_factor=2, mode='nearest')))

        mask = self.conv_before_upsample_mask(mask)
        mask = self.lrelu(self.conv_up2_mask(F.interpolate(mask, scale_factor=2, mode='nearest')))


        out_dict={}
        out_dict['out'] =out
        out_dict['mask'] = mask
        return out_dict
if __name__ == '__main__':
    import torch

    x = torch.rand(1, 48, 64, 64)
    z = torch.rand(1, 48, 64, 64)
    w = torch.rand(1, 96, 64, 64)
    t = torch.ones(1)
    mask=torch.randn(1, 3, 64, 64)
    model=CST(dim=48, stage=2, num_blocks=[2, 2, 2])
    out,mask=model(x,mask, t,z, w)
    print(out.shape,mask.shape)












