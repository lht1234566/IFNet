# GENERATED VERSION FILE
# TIME: Tue Apr  8 15:33:22 2025
__version__ = '1.4.2'
__gitsha__ = 'unknown'
version_info = (1, 4, 2)
